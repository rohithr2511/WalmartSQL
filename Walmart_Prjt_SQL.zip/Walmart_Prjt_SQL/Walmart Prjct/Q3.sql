select * from walmartsales;

select Customer_ID,round(sum(total),2) as Total_purch_amt,
CASE
when Sum(Total) < 20000 then 'LOW'
when sum(Total) between 20000 and 21000 then 'MEDIUM'
else 'HIGH'
end as 'Customer_Segments'
from walmartsales
group by Customer_ID
order by Customer_ID,Total_purch_amt DESC;
