select * from walmartsales;
WITH monthly_sales AS (
    SELECT Branch, MONTH(Date) AS Month, SUM(Total) AS Total_Sales
    FROM walmartsales
    GROUP BY Branch, MONTH(Date)
),
growth_rate AS (
    SELECT Branch, Month, Total_Sales,LAG(Total_Sales) OVER (PARTITION BY Branch ORDER BY Month) AS Prev_Sales
    FROM monthly_sales
)
SELECT Branch, ROUND(AVG((Total_Sales - Prev_Sales) / Prev_Sales * 100),2) AS Avg_Growth_Rate
FROM growth_rate
GROUP BY Branch
ORDER BY Avg_Growth_Rate DESC
LIMIT 1;