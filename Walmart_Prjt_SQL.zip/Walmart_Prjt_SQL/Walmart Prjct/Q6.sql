select * from walmartsales;

select monthname(date)as month_sales, Gender,round(Sum(Total),2) as sales
from walmartsales
group by month_sales,Gender;