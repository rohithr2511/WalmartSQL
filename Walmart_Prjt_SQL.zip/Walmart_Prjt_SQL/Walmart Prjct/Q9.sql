select * from walmartsales;

select Customer_ID,Customer_type,ROUND(SUM(Total),2) as Total_Revenue
from walmartsales
group by Customer_ID,Customer_type
Order by Total_Revenue Desc
Limit 5;