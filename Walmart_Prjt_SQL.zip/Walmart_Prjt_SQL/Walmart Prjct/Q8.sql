SELECT 
    Customer_ID, 
    COUNT(*) AS Repeat_Purchases
FROM walmartsales
GROUP BY Customer_ID
HAVING COUNT(*) > 1;