SELECT * FROM walmartsales;

desc walmartsales;

alter table walmartsales
modify Date date;

update walmartsales
set Date=str_to_date(Date,"%d-%m-%Y");