SELECT * FROM walmartsales;

WITH product_avg_sales AS (
    SELECT Product_line, AVG(Total) AS Avg_Sales
    FROM walmartsales
    GROUP BY Product_line
)
SELECT w.Invoice_ID,w.Customer_ID,w.Branch,w.Customer_type,w.Unit_price,w.Total
FROM walmartsales w
JOIN product_avg_sales p ON w.Product_line = p.Product_line
WHERE w.Total > 2 * p.Avg_Sales OR w.Total < 0.5 * p.Avg_Sales;