select * from walmartsales;

select Branch,Product_line, Round(SUM(gross_income - Unit_price),2) as Profit
from walmartsales
group by Branch, Product_line
order by Branch,Profit Desc;