select * from walmartsales;

select city,payment,Count(payment) as popular
from walmartsales
group by city,payment
order by popular desc;