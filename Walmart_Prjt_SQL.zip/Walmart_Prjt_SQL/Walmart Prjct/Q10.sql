SELECT 
    DAYNAME(Date) AS Day, 
    ROUND(SUM(Total),2) AS Total_Sales
FROM walmartsales
GROUP BY DAYNAME(Date)
ORDER BY Total_Sales DESC;